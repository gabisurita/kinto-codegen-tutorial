# Batch

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**requests** | [**list[BatchRequests]**](BatchRequests.md) | List of operations that should be performed. | [optional] 
**defaults** | [**BatchDefaults**](BatchDefaults.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


