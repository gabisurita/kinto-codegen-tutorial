# CollectionPermissions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**read** | **string[]** | List of user principals that can read the collection object and all its records. | [optional] 
**write** | **string[]** | List of user principals that can read read, update and delete the collection object and all its records. | [optional] 
**recordcreate** | **string[]** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


