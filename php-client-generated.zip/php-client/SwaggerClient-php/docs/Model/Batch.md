# Batch

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**requests** | [**\Swagger\Client\Model\BatchRequests[]**](BatchRequests.md) | List of operations that should be performed. | [optional] 
**defaults** | [**\Swagger\Client\Model\BatchDefaults**](BatchDefaults.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


