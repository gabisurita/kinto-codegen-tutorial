# BucketPermissions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**read** | **string[]** |  | [optional] 
**write** | **string[]** |  | [optional] 
**groupcreate** | **string[]** |  | [optional] 
**collectioncreate** | **string[]** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


